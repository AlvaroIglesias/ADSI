package packCodigo;

import packVentanas.VLogin;

public class Main {

	public static void main(String[] args) 
			throws NoArchivoAudioException {
		VLogin vL = new VLogin();
		vL.setVisible(true);
	}
}
