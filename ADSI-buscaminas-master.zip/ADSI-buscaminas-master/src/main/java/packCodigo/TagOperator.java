package packCodigo;

public interface TagOperator {
	
      void invokeEnd();
      
}
