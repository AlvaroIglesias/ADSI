package packCodigo;

public class XmlParsingException extends Exception {
	
	
private static final long serialVersionUID = -7078684339006327479L;

	
	
	public XmlParsingException() {
	}

	
	
	public XmlParsingException(String arg0) {
		super(arg0);
	}

	
	
	public XmlParsingException(Throwable arg0) {
		super(arg0);
	}

	
	
	public XmlParsingException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	
	
}
