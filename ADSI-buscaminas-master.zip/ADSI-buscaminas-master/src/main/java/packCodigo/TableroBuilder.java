package packCodigo;

public abstract class TableroBuilder {
	
	private Tablero elTablero;

	//-------------------------------------------//
	

	public TableroBuilder(){
		
	}

	
	public Tablero asignarTablero(){
		return elTablero;
	}
	
}
