
package packCodigo;

public class CasillaMina extends Casilla{
	
	public CasillaMina(){
		super();
	}
	
	public void descubrir(){
		super.descubrir();
	}
	
	public void inicializar(String coor){
		super.inicializar(coor);
	}
	
	public void cambioBandera(){
		super.cambioBandera();
	}
	
	
}
