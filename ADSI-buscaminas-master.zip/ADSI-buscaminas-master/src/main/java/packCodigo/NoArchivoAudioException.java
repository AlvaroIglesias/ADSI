package packCodigo;

public class NoArchivoAudioException extends Exception {
    public NoArchivoAudioException() {
        super();
    }
}
